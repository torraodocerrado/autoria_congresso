#require 'shdm/operation'

class ExecuteController < ApplicationController
  include SwuiController
  include Operations
end