SWUI::Effect

class SWUI::Effect

	property SWUI::effect_name, 'rdfs:subPropertyOf' => RDFS::label
  property SWUI::effect_dependencies
	property SWUI::effect_jsCode

end